sTarPicker: a Method for Efficient Prediction of Bacterial sRNA Targets 
based on a Two-step Model for Hybridization
Copyright (C) 2011 Center of Computational Biology, 
Beijing Institute of Basic Medical Sciences
-------------------------

Introduction
------------

sTarPicker was proposed based on a two-step model for hybridization 
between an sRNA and an mRNA target. This method first selects stable 
duplexes after screening all possible duplexes between the sRNA and 
the potential mRNA target. Next, hybridization between the sRNA and 
the target is extended to span the entire binding site. Finally, 
quantitative predictions are produced with an ensemble classifier 
generated using machine-learning methods. In calculations to determine 
the hybridization energies of seed regions and binding regions, both 
thermodynamic stability and site accessibility of the sRNAs and targets 
were considered. Comparisons with the existing methods showed that 
sTarPicker performed best in both performance of target prediction and 
accuracy of the predicted binding sites. 

The Web service of sTarPicker is available at http://ccb.bmi.ac.cn/starpicker/prediction.php.
The stand alone version can be downloaded at http://ccb.bmi.ac.cn/starpicker/.


For more information, see the paper published in PLoS One:

Xiaomin Ying, Yuan Cao, Jiayao Wu, Qian Liu, Lei Cha, Wuju Li. 
sTarPicker: a method for efficient prediction of bacterial sRNA targets 
based on a two-step model for hybridization. 
PLoS ONE 6(7): e22705.
PMID: 21799937

http://dx.plos.org/10.1371/journal.pone.0022705

If you have any questions about redistributing sTarPicker or using 
sTarPicker code in your own work, see the files:
COPYRIGHT    -- copyright notice
LICENSE      -- version 3 of the GNU Public License (see COPYRIGHT)

Installation
------------
You must install first Ivo Hofacker's ViennaRNA package, available from:
http://www.tbi.univie.ac.at/~ivo/RNA/
For the convenience, we provide ViennaRNA version 1.8.4 attached to sTarPicker 
compressed file.

If you have root privilege, you'll just have to type:
----------
	tar zxvf ViennaRNA-1.8.4.tar.gz
	cd ViennaRNA-1.8.4
	./configure
	make
and (as root)
	make install 
	cd Utils
	cc -o b2ct b2ct.c
	
If you do not have root privilege, you can install ViennaRNA as follows:
----------
	tar zxvf ViennaRNA-1.8.4.tar.gz
	cd ViennaRNA-1.8.4
	./configure --prefix=/your own directory, e.g. /home/yourname
	make
	make install 
	cd Utils
	cc -o b2ct b2ct.c

Please read the file INSTALL provided by ViennaRNA package for detailed information.

Then proceed like this:
  tar zxvf starpicker.tar.gz (create starpicker directory)
  cd starpicker
  cp /your path to ViennaRNA-1.8.4/Utils/b2ct .

  You're done.
  
Usage
-----

perl sTarPicker_global.pl -srna sRNA sequences in fasta format -gen genome sequences in fasta format -ptt ptt files in ptt format -th the threshold for sTarPicker
     
   Parameters:
   -srna         sRNA sequences in fasta format, supporting multiple sRNA sequences;   
   -gen          genome sequences in fasta format, which can be downloaded from GenBank;
   -ptt          ptt files in ptt format, which can be downloaded from GenBank;
   -th           the threshold for sTarPicker, ranging from 0.001 to 1.
   
   Example:
   perl sTarPicker_global.pl -srna Yfr1.fasta -gen NC_005072.fna -ptt NC_005072.ptt -th 0.5

Contact
------------

If any problem, please contact:
Xiaomin Ying
yingxm at bmi.ac.cn  OR  yingxmbio at gmail.com
Center of Computational Biology
Beijing Institute of Basic Medical Sciences
China
